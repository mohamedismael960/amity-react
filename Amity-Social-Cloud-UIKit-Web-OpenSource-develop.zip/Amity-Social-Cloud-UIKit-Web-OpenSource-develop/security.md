# Security policy

Please refer to the [Amity security policies](https://docs.amity.co/support/security)
