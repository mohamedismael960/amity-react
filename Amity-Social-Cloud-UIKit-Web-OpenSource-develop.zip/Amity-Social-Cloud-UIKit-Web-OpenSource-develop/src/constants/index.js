export const LIKE_REACTION_KEY = 'like';
