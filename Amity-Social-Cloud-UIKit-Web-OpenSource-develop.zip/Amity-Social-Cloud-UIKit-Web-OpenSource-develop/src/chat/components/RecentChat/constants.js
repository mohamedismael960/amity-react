// TODO: Tabs component must to be fixed to provide proper constants and localization
export const CHAT_TYPES = {
  GROUP: 'Group Chat',
  DIRECT: 'Direct Chat',
};
