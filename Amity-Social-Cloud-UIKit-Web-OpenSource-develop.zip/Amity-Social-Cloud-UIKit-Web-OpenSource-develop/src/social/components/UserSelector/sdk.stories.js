import React from 'react';

import UiKitUserSelector from '.';

export default {
  title: 'SDK Connected/Social/UserSelector',
};

export const SDKUserSelector = () => {
  return <UiKitUserSelector />;
};
