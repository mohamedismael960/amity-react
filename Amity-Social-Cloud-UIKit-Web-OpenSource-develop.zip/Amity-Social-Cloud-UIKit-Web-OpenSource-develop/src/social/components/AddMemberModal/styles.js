import styled from 'styled-components';

export const FormContainer = styled.div`
  border-bottom: 1px solid ${({ theme }) => theme.palette.base.shade4};
`;
