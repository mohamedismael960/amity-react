export const Tabs = {
  EDIT_PROFILE: 'EDIT_PROFILE',
};

export const tabs = [{ value: Tabs.EDIT_PROFILE, label: 'Edit profile' }];
