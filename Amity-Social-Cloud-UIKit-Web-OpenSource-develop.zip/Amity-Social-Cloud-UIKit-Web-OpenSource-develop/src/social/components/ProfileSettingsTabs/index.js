import customizableComponent from '~/core/hocs/customization';

import { ProfileSettingsTabs } from './styles';

export default customizableComponent('ProfileSettingsTabs', ProfileSettingsTabs);
