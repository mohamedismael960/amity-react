import Remove from './Remove';

export default Remove;
