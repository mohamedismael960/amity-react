import { useSDK } from '~/core/hocs/withSDK';

export { useSDK };
export default useSDK;
