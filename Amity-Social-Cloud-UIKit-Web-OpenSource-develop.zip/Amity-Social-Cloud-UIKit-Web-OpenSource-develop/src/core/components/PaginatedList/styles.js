import styled from 'styled-components';

export const ChevronDownContainer = styled.span`
  display: inline-block;
  margin-left: 5px;

  svg {
    vertical-align: middle;
  }
`;
