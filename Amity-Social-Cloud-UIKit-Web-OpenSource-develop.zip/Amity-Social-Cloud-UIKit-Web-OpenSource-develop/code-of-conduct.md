# Code of conduct

Please refer to the [Amity code of conduct](https://docs.amity.co/support/code-of-conduct)
