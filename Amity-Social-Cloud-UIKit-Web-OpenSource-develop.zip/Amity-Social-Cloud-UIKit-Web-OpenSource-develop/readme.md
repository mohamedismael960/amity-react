# Amity Ui-Kit for Web (open-source)

## Getting started

### Installation

1. git clone git@github.com:AmityCo/Amity-Social-Cloud-UIKit-Web-OpenSource.git
2. cd Amity-Social-Cloud-UIKit-Web-OpenSource
3. npm ci
4. npm build
5. npm link

Then, inside another project, where need to use ui-kit:

1. npm link @amityco/ui-kit-open-source --install-links --save

### Documentation

Please refer to our online documentation at https://docs.amity.co or contact a Ui-Kit representative at **developers@amity.co** for support.

## Contributing

See [our contributing guide](https://github.com/EkoCommunications/AmityUiKitWeb/blob/develop/CONTRIBUTING.md)
